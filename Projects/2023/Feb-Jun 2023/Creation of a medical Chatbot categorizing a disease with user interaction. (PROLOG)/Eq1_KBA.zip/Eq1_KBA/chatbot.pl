%Enfermedad y sus sintomas

sick(resfriado) :- congestion(nasal), estornudos(frecuentes), dolor(garganta), dolor(cabeza), tos(seca), feel(fatiga),
                   fiebre(moderada);
                   congestion(nasal), estornudos(frecuentes), dolor(garganta), dolor(oido), tos(flema), feel(fatiga),
                   fiebre(moderada);
                   congestion(nasal), estornudos(frecuentes), dolor(garganta), dolor(cabeza), tos(flema), feel(normal),
                   fiebre(alta).

sick(rinofaringitis) :- congestion(nasal), secrecion(nasal),estornudos(frecuentes), dolor(garganta), dolor(cabeza), 
                        tos(seca), feel(fatiga),fiebre(alta);
                        congestion(nasal), secrecion(nasal),estornudos(frecuentes), dolor(garganta), dolor(cabeza), 
                        tos(seca), feel(fatiga_leve),fiebre(alta);
                        congestion(nasal), secrecion(nasal),estornudos(frecuentes), dolor(garganta), dolor(cabeza), 
                        tos(flema), feel(fatiga_leve),fiebre(alta).


sick(faringoamigdalitis) :- dolor(garganta), dificultad(tragar), throat(inflamación), fiebre(alta),
                            dolor(cabeza),dolor(oido),feel(fatiga), voz(ronca), amigdalas(malas); 
                            dolor(garganta), dificultad(tragar), throat(inflamación),
                            dolor(oido),feel(fatiga), voz(ronca), amigdalas(malas).

sick(otitis_media_supurada) :- dolor(oido), secrecion(oido), fiebre(leve), feel(mareos), dolor(cabeza). 

sick(otitis_media_no_supurada) :- dolor(oido), feel(plenitud), perdida(audición), feel(mareos), fiebre(moderada),
                                  feel(fatiga), dolor(cabeza);
                                  dolor(oido), feel(presion), perdida(audición), feel(mareos), fiebre(alta),
                                  feel(fatiga), dolor(cabeza).

sick(gastroenteritis) :- dolor(abdominal), nauseas(constantes), diarrea(acuosa),fiebre(leve),perdida(apetito),
                        feel(fatiga), dolor(cabeza);
                        dolor(abdominal), nauseas(constantes), diarrea(acuosa),fiebre(moderada),perdida(apetito),
                        feel(fatiga), dolor(cabeza).

sick(infeccion_urinaria) :- dolor(orinar), urgencia(orinar), orina(turbia), dolor(abdominal), feel(presion),feel(fatiga),
                            fiebre(leve), orina(olor_fuerte);
                            dolor(orinar), urgencia(orinar), orina(color_oscuro), dolor(abdominal), feel(presion),feel(fatiga),
                            fiebre(leve), orina(olor_fuerte);
                            dolor(orinar), urgencia(orinar), orina(turbia), dolor(abdominal), feel(presion),feel(fatiga),
                            fiebre(leve), orina(olor_desagradable);
                            dolor(orinar), urgencia(orinar), orina(color_oscuro), dolor(abdominal), feel(presion),feel(fatiga),
                            fiebre(leve), orina(olor_desagradable).


%Categorias

dolor(garganta) :- throat(inflamación), voz(ronca), dificultad(tragar);
                   throat(inflamación), voz(ronca), manchas(blancas);
                   throat(inflamación), voz(ronca), manchas(amarillas).
dolor(cabeza) :- sensible(luz), nauseas(constantes), tensión(musculos);
                 sensible(sonido), nauseas(leves), feel(debil), tensión(cuello).
dolor(oido) :- feel(presion), sensible(sonido), feel(mareos).
dolor(abdominal) :- feel(presion), sensible(estomago), feel(mareos), tensión(musculos).
dolor(orinar) :- feel(presion), sensible(pelvis).

amigdalas(malas) :- amigdala(enrojecimiento), amigdala(agrandamiento), manchas(blancas).

secrecion(oido) :- dolor(oido), perdida(audición), feel(plenitud).

%Relaciones

familia(respiratorio, [resfriado, rinofaringitis, faringoamigdalitis]).
familia(oido, [otitis_media_supurada, otitis_media_no_supurada]).
familia(gástrico, [gastroenteritis]).
familia(urinario,[infeccion_urinaria]).

familia_enfermedad(X, Y) :-
    familia(X, Enfermedades),
    member(Y, Enfermedades).

medicina([ibuprofeno,acetaminofen,descongestionante],X) :- familia_enfermedad(respiratorio, X).
medicina([amoxicilina,cefuroxima],X) :- familia_enfermedad(oido, X).
medicina([solución_rehidratación_oral],X) :- familia_enfermedad(gástrico, X).
medicina([visite_a_su_medico],X) :- familia_enfermedad(urinario, X).


:- discontiguous [dolor/1, secrecion/1, estornudos/1, congestion/1, throat/1, voz/1, 
                dificultad/1, manchas/1, sensible/1, nauseas/1, tensión/1, tos/1, 
                feel/1, fiebre/1, amigdala/1, perdida/1, diarrea/1, medicina/2,familia/2,familia_enfermedad/2].

% ChatBot

secrecion(X) :- ask(secrecion, X). 
estornudos(X) :- ask(estornudos, X).
congestion(X) :- ask(congestion, X).
throat(X) :- ask(throat, X).
voz(X) :- ask(voz,X).
dificultad(X) :- ask(dificultad,X).
manchas(X) :- ask(manchas,X).
sensible(X) :- ask(sensible,X).
nauseas(X) :- ask(nauseas,X).
tensión(X) :- ask(tensión, X).
tos(X) :- ask(tos, X).
feel(X) :- ask(feel, X).
fiebre(X) :- ask(fiebre, X).
amigdala(X) :- ask(amigdala,X).
perdida(X) :- ask(perdida,X).
diarrea(X) :- ask(diarrea,X).
urgencia(X) :- ask(urgencia,X).
orina(X) :- ask(orina,X).

% Segunda forma
ask(A, B) :- known(si, A, B), !.
ask(A, B) :- known(_, A, B), !, fail. 
ask(A, B) :- write(A : B :' ? '), read(Y), Y == si, assert( known(Y, A, B) ).

% tercera forma (complementa a la segunda)
top_goal(X) :- sick(X).

medbot :- 
        abolish(known/3),
		dynamic(known/3),
        write('¡Bienvenido a MedBot! Soy un chatbot médico que puede ayudarte a identificar     enfermedades comunes y brindarte recomendaciones de medicamentos.               Escribe si. o no. a los sintomas que apliquen.'), nl,
		top_goal(X),
        write('La enfermedad es: '), write(X), nl,
        medicina(M,X),
        write('Le recomendamos: '), write(M), nl.
         

medbot :- write('No se'), nl. 